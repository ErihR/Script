const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('texttonormal')
        .setDescription('no description')
        .addStringOption(option => option
            .setName(`text`)
            .setDescription(`-`)
            .setRequired(true)
        )
    ,
    async execute(interaction, client) {

        const text = interaction.options.getString(`text`);

        interaction.channel.send(text)

        interaction.reply({
            ephemeral: true,
            content: `Done`
        })

    }
}
