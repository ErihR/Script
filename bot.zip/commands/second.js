const { ButtonBuilder } = require('@discordjs/builders');
const { SlashCommandBuilder, EmbedBuilder, ButtonInteraction, ButtonStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('second')
        .setDescription('no description')

        .addStringOption(option => option
            .setName(`text`)
            .setDescription(`-`)
            .setRequired(true)
        )

        .addStringOption(option => option
            .setName(`url`)
            .setDescription(`-`)
            .setRequired(true)
        )

    ,
    async execute(interaction, client) {

        const text = interaction.options.getString(`text`);
        const url = interaction.options.getString(`url`);


        const embed = new EmbedBuilder()
            .setColor(`Blue`)
            .setTitle(`About Embed Generator`)
            .setDescription(`Embed Generator is a powerful tool that enables you to create visually appealing and interactive embed messages for your Discord server. With the use of

webhooks, Embed Generator allows you to customize the appearance of your messages and make them more engaging.

To get started, all you need is a webhook URL, which can be obtained from the 'Integrations' tab in your server's settings. If you encounter any issues while setting up a webhook, our bot can assist you in creating one.

Instead of using webhooks you can also select a server and channel directly here on the website. The bot will automatically create a webhook for you and use it to send the message.`)


        const urlButton = new ButtonBuilder()
            .setStyle(ButtonStyle.Link)
            .setLabel(`Кнопка 1`)
            .setURL(url)

        const row = new ActionRowBuilder()
            .setComponents(urlButton)


        await interaction.channel.send({
            content: text,
            embeds: [embed],
            components: [row]
        })


        interaction.reply({
            ephemeral: true,
            content: `Done`
        })

    }
}
